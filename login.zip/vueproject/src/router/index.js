import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

Vue.use(Router)

export default new Router({
  routes: [
    // 登录页面
    {
      path:'/login',
      name: 'login',
      component: () => import('../page/login.vue'),
    },

    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    }

  ]
})
