<template>
  <div id="login">
    <el-form action="" :model="loginForm" :rules="rules" ref="loginForm" status-icon="true" >
        <h2>{{tip}}</h2>
        <el-form-item  label="用户名:" prop="userName" >
            <el-input v-model="loginForm.userName"  placeholder="请输入用户名" clearable  autocomplete="off">
            </el-input>
        </el-form-item>
        <el-form-item  label="密码:" prop="password">
            <el-input  v-model="loginForm.password" type='password' placeholder="请输入密码" clearable autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="" >注册</el-button>
            <el-button type="submit" @click="submitForm('loginForm')">登录</el-button>
        </el-form-item>
        <a href="#">忘记密码？</a>
    </el-form>
    </div>
</template>

<script>
    export default {
        name: 'login',
        data() {
            // 密码校验函数
            var pwValidate = (rule,value,callback) =>{
                if ( value.length < 6 || value.length > 14) {
                    callback(new Error('密码长度为6~14位'));
                } else if (!/[a-zA-Z]/.test(value) || !/\d/.test(value)) {
                    callback(new Error('密码应包含英文字符和数字'));
                } else {
                    callback();
                }
            };
            return {
                tip: '欢迎登录！',
                loginForm:{
                    userName: '',
                    password: '',
                },
                rules: {
                    // 验证规则
                    userName:[
                        {required: true, message: '用户名不能为空', trigger: 'blur'}
                    ],

                    password:[
                        {required: true, message: "请输入密码", trigger: 'blur'},
                        {validator: pwValidate, trigger: 'blur'}
                    ]
                }
            } 
        },
        methods: {
            // 提交验证表单
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        alert("正在登录...");
                    } else {
                        return false;
                    }

                })
                
            }
        }
    }
</script>

<style>

    * {
        margin: 0;
        padding: 0;
    }

    html,body {
        height: 100%;
    }
    
    /* 在index.html 中 */
    #app {
        margin: 0%;
        height: 100%;
        background: url(../assets/1.jpeg) no-repeat 0px 0px/cover fixed;
    }
     
    h2 {
        margin-bottom: 1.25rem;
    }

 /* 根元素html 16px  */
   .el-form {
    margin-top: 5rem; 
    margin-right: 5rem;
    padding: 2rem;
    float: right;
    background-color: rgba(0, 0, 0, 0.2);
   }

   .el-form-item__label {
    display: inline-block;
    float:none;
    width: 5rem;
    text-align: right;
    color: azure;
    font-weight: bold;
   }

   .el-form-item__content {
    display: inline-block;
   }
</style>

